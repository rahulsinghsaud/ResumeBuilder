import React, {Component} from 'react'
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Person from '../Details/Person'
import Address from '../Details/Person'
import Skills from '../Details/Person'
import Titles from '../Details/Person'
import Employment from '../Details/Person'
import Degrees from '../Details/Person'
import References from '../Details/Person'
import Login from '../Details/Login'
import Header from './Header'



export default class AsideMenu extends Component {
  state = {
    showLogin: false,
    login: ''
  }

  handleLoginToggle = () => {
    this.setState({
      showLogin: !this.state.showLogin
    })
  }

  handleLoginName = (loginName) => {
    this.setState({
      login: loginName
    })
  }

  render() {
    return (
      <div>
        <Header></Header>
        <Router>
          <section className="hero is-black is-fullheight">
            <div className="hero-body">
              <div className="container">
                <div className="columns is-vcentered">
                  <div className="column is-3">
                    <aside className="menu">
                      <p className="menu-label">
                        Your Information(Person)
  </p>
                      <ul className="menu-list">
                        <li>
                          <Link to="/Person">Person</Link>
                        </li>
                        <li>
                          <Link to="/Login" >Login</Link>
                        </li>
                      </ul>
                      <p className="menu-label">
                        Title & Skills
  </p>
                      <ul className="menu-list">
                        <ul>
                          <li> <Link to="/Titles">Titles</Link></li>
                          <li> <Link to="/Skills">Skills</Link></li>
                        </ul>
                      </ul>
                      <p className="menu-label">
                        Work History
  </p>
                      <ul className="menu-list">
                        <li><Link to="/Employment">Employment</Link></li>
                      </ul>
                      <p className="menu-label">
                        Educations
  </p>
                      <ul className="menu-list">
                        <li><Link to="/Degrees">Degrees</Link></li>
                      </ul>
                      <p className="menu-label">
                        References
  </p>
                      <ul className="menu-list">
                        <li><Link to="/References" >References</Link></li>
                      </ul>
                    </aside>

                  </div>

                  <div className="column is-info has-text-primary">
                    <p className="bd-notification is-primary">
                    <div class="box">                   
                    <article class="media">
                        {/* <div class="media-left">
                            <figure class="image is-64x64">
                                <img src="https://bulma.io/images/placeholders/128x128.png" alt="Image" />
                            </figure>
                        </div> */}
                        <div class="media-content">
                            <div class="content">
                                <p>
                                    <strong>John Smith</strong> <small>@johnsmith</small> <small>31m</small>
                                    <br></br>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean efficitur sit amet massa fringilla egestas. Nullam condimentum luctus turpis.
        </p>
                      <Route path="/Person" exact component={Person} />
                      <Route path="/Address" exact component={Address} />
                      <Route path="/Titles" exact component={Titles} />
                      <Route path="/Skills" exact component={Skills} />
                      <Route path="/Employment" exact component={Employment} />
                      <Route path="/Degrees" exact component={Degrees} />
                      <Route path="/References" exact component={References} />
                      <Route path="/Login" exact component={Login} />
                                </div>
                        </div>
                    </article>
                </div>
                
                      
                </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </Router>
      </div>
    )
  }
}


