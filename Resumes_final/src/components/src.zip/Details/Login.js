import React, { Component } from 'react'
import { Link, Redirect } from 'react-router-dom';

export default class Login extends Component {
    state = {
        email: '',
        password: '',
        validEmail: true,
        validPassword: true,
        dirtyEmail: false,
        dirtyPassword: false,
        showLogin: false,
        redirectToReferrer: false
    }
    handleChange = ({ target: { name, value } }) => {
        // console.log(name, value)

        if (name === 'email') {
            const validEmail = value.length > 5 && true // later on add regax for email validation
            this.setState({
                validEmail,
                email: value,
                dirtyEmail: true
            })
        }
        if (name === 'password') {
            const validPassword = value.length > 5 && true// later on add regax for email validation
            this.setState({
                validPassword,
                password: value,
                dirtyPassword: true
            })
        }

        //valid && this.props.onDateReset(date)  
    }

    handleSubmit = e => {
        e.preventDefault();
        //console.log('Rahul is :' + this.state.email)
        // this.props.onLoginName()
        if (this.state.showLogin && this.state.validEmail && this.state.validPassword && this.state.dirtyEmail && this.state.dirtyPassword) {
            console.log('I am inside if clause')
            // this.props.onToggle()
            // this.props.onLoginName(this.state.email)
            this.handleLoginToggle()
            fetch('https://jsonplaceholder.typicode.com/todos/1')
                .then(response => response.json())
                .then(json => console.log(json))
            this.setState({
                redirectToReferrer: true
            })
        }
        //this.setState({ active: false });        


        // this.setState({
        //     email: ,
        //     password: '',
        //     validEmail: true,
        //     validPassword: true,
        //     dirtyEmail: false,
        //     dirtyPassword: false
        // })
        console.log('I am outside if clause')
        return <Redirect to="/Login" />
    }

    handleLoginToggle = () => {
        this.setState({
            showLogin: !this.state.showLogin
        })
    }

    render() {
        let { email, password, validEmail, validPassword, dirtyEmail, dirtyPassword, showLogin, redirectToReferrer } = this.state,
            classesEmail = 'input ',
            classesPassword = 'input '
        validEmail && dirtyEmail && (classesEmail += ' is-success')
        !validEmail && dirtyEmail && (classesEmail += ' is-danger')
        validPassword && dirtyPassword && (classesPassword += ' is-success')
        !validPassword && dirtyPassword && (classesPassword += ' is-danger')

        const redirectToReferrers = redirectToReferrer;
        if (redirectToReferrers === true) {
            return <Redirect to="/AsideMenu" />
        }
        return (
            <div>
                {/* is-invisible */}
                <div class="columns">
                    <div class="column is-2"> <Link to="/Person" className="button is-small is-info">Back</Link></div>
                    <div class="column is-6"><button className="button is-large is-danger"  onClick={this.handleLoginToggle}> Add Login Details</button></div>
                    <div class="column is-2"> <Link to="/Titles" className="button is-small is-info">Next</Link></div>
                   
                </div>
                <table class="table " >
                    <thead>
                        <tr>
                            <th><abbr title="Position">Pos</abbr></th>
                            <th>Team</th>
                            <th><abbr title="Played">Pld</abbr></th>
                            <th><abbr title="Won">W</abbr></th>
                            <th><abbr title="Drawn">D</abbr></th>
                            <th><abbr title="Lost">L</abbr></th>
                            <th><abbr title="Goals for">GF</abbr></th>
                            <th><abbr title="Goals against">GA</abbr></th>
                            <th><abbr title="Goal difference">GD</abbr></th>
                            <th><abbr title="Points">Pts</abbr></th>
                            <th>Qualification or relegation</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><abbr title="Position">Pos</abbr></th>
                            <th>Team</th>
                            <th><abbr title="Played">Pld</abbr></th>
                            <th><abbr title="Won">W</abbr></th>
                            <th><abbr title="Drawn">D</abbr></th>
                            <th><abbr title="Lost">L</abbr></th>
                            <th><abbr title="Goals for">GF</abbr></th>
                            <th><abbr title="Goals against">GA</abbr></th>
                            <th><abbr title="Goal difference">GD</abbr></th>
                            <th><abbr title="Points">Pts</abbr></th>
                            <th>Qualification or relegation</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <tr>
                            <th>1</th>
                            <td><a href="https://en.wikipedia.org/wiki/Leicester_City_F.C." title="Leicester City F.C.">Leicester City</a> <strong>(C)</strong>
                            </td>
                            <td>38</td>
                            <td>23</td>
                            <td>12</td>
                            <td>3</td>
                            <td>68</td>
                            <td>36</td>
                            <td>+32</td>
                            <td>81</td>
                            <td>Qualification for the <a href="https://en.wikipedia.org/wiki/2016%E2%80%9317_UEFA_Champions_League#Group_stage" title="2016–17 UEFA Champions League">Champions League group stage</a></td>
                        </tr>
                    </tbody>
                </table>
                <div className={'modal ' + (showLogin ? ' is-active' : '')}>
                    <div className="modal-background"></div>    {/*onClick={this.handleLoginToggle} */}
                    <div className="modal-card">
                        <header className="modal-card-head">
                            <p className="modal-card-title">Login Form</p>
                            <button className="delete" aria-label="close"
                                onClick={this.handleLoginToggle}></button>
                        </header>
                        <section className="modal-card-body">

                            <div className="field">
                                <p className="control has-icons-left has-icons-right">
                                    <input name="email" className={classesEmail} type="email" placeholder="Email"
                                        value={email}
                                        onChange={this.handleChange} />
                                    <span className="icon is-small is-left">
                                        <i className="fas fa-envelope"></i>
                                    </span>
                                    <span className="icon is-small is-right">
                                        <i className="fas fa-check"></i>
                                    </span>
                                </p>
                            </div>
                            <div className="field">
                                <p className="control has-icons-left">
                                    <input name="password" className={classesPassword} type="password" placeholder="Password"
                                        value={password}
                                        onChange={this.handleChange} />
                                    <span className="icon is-small is-left">
                                        <i className="fas fa-lock"></i>
                                    </span>
                                </p>
                            </div>
                            <div className="buttons is-right">
                                <button className="button is-success" onClick={this.handleSubmit}>Login</button>
                                <button className="button is-info">Reset</button>
                            </div>
                        </section>
                        <footer className="modal-card-foot">
                            {/* <button className="button is-success">Save changes</button>
                        <button className="button">Cancel</button> */}
                        </footer>
                    </div>
                </div>
                
            </div>
        )
    }
}